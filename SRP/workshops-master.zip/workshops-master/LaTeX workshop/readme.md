
Indsæt indholdet af emacs-configuration.el i din ~/.emacs fil.

Læg preamble.tex I ~/.emacs.d/templates/ mappe
